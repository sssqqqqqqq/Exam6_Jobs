package com.example.lpz_6.config;

public class Config {
    public final static String BASE_URL = "http://47.98.43.21:5569/";
}
